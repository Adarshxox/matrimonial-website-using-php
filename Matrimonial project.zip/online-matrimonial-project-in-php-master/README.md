# online-matrimonial-project-in-php
visit my website 
http://projectworlds.in/online-matrimonial-project-in-php/

Online Matrimonial Website is an online web portal that enables a user to find partners by choice.
It is a free project on PHP in which a user needs to 
first register by entering some details and 
then he will have access to choose his/her life 
partner based on his preferences.
Online matrimonial project in PHP is a totally dynamic web portal and is managed by admin from back-end.

