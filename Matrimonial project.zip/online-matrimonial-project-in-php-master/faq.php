<?php include_once("includes/basic_includes.php");?>
<?php include_once("functions.php"); ?>

<!DOCTYPE HTML>
<html>
<head>
<title>Find Your Perfect Partner - magic frames Matrimony | Faq :: magic frames Matrimony
</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap-3.1.1.min.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Oswald:300,400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Ubuntu:300,400,500,700' rel='stylesheet' type='text/css'>
<!----font-Awesome----->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!----font-Awesome----->
<script>
$(document).ready(function(){
    $(".dropdown").hover(            
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideDown("fast");
            $(this).toggleClass('open');        
        },
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideUp("fast");
            $(this).toggleClass('open');       
        }
    );
});
</script>
</head>
<body>
<!-- ============================  Navigation Start =========================== -->
<?php include_once("includes/navigation.php");?>
<!-- ============================  Navigation End ============================ -->
<div class="grid_3">
  <div class="container">
   <div class="breadcrumb1">
     <ul>
        <a href="index.php"><i class="fa fa-home home_1"></i></a>
        <span class="divider">&nbsp;|&nbsp;</span>
        <li class="current-page">FAQ</li>
     </ul>
   </div>
   <dl class="faq-list">
	<dt class="faq-list_h">
	<h4 class="marker">Q?</h4>
	<h4>what can we do in this website?</h4>
	</dt>
	<dd>
	<h4 class="marker1">A.</h4>
	<p class="m_4">In this project, we will create a matrimonial website using PHP and 
                   JavaScript. A matrimonial website is a platform where people can find their 
                   potential partners for marriage. The website will have features such as user 
                   registration, profile creation, partner search, and more.</p>
	</dd>
	<dt class="faq-list_h">
	<h4 class="marker">Q?</h4>
	<h4>The main objectives of this project are:</h4>
	</dt>
	<dd>
	<h4 class="marker">A.</h4>
	<p class="m_4">-  To improve the security and privacy of the users' data and communication 
                      by using encryption, authentication, and authorization techniques.
                    - To enhance the compatibility and personalization of the matching algorithm 
                      by using artificial intelligence, machine learning, and natural language 
                      processing techniques.
                    - To improve the user experience and engagement by using responsive 
                      design, interactive elements, and gamification techniques.
                    - To increase the scalability and performance of the website by using cloud 
                      computing, caching, and load balancing techniques.</p>
	</dd>
	<dt class="faq-list_h">
	<h4 class="marker">Q?</h4>
	<h4>The expected outcomes of this project are:</h4>
	</dt>
	<dd>
	<h4 class="marker">A.</h4>
	<p class="m_4">- A prototype of a matrimonial website that incorporates the proposed 
                     enhancements using PHP and javascript.
                   - A report that documents the design, implementation, testing, and evaluation 
                     of the prototype.
                   - A presentation that showcases the features and benefits of the prototype.
</p>
	</dd>
	
  </div>
</div>


<?php include_once("footer.php");?>

